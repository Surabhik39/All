class SmartPhone extends Mobile
			{
				constructor(id,name,cost,type){
					super(id,name,cost);
					this.type=type;
				}
				printAllProduct()
				{
					super.printAllProduct();
					console.log("Mobile Type:"+this.type)
					
				}
			}
			var obj2=new SmartPhone(2,"Oppo",15000,"Smart phone")
			console.log(obj2.printAllProduct())
			
			 var title = [1,'dfr',1500,'smart'];
			 for (var i=0; i<1; i++) {
    title[i] = {
		id: "id" ,
        name: "name",
        cost: "cost",
        type: "type"
    };
}
console.log(title);