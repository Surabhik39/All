class BasicPhone extends Mobile
			{
				constructor(id,name,cost,type){
					super(id,name,cost);
					this.type=type;
				}
				printAllProduct()
				{
					super.printAllProduct();
					console.log("Mobile Type:"+this.type)
					
				}
			}
			var obj1=new BasicPhone(1,"Vivo",12000,"Basic phone")
			console.log(obj1.printAllProduct())