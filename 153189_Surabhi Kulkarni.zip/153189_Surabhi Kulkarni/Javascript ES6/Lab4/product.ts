class Product{
				constructor(id,name,cost){
					this.id=id;
					this.name=name;
					this.cost=cost
				}
				printAllProduct()
				{
					console.log("Product ID:"+this.id)
					console.log("Product Name:"+this.name)
					console.log("Product cost:"+this.cost)
				}
			}
			
			
class Product1 extends Product
			{
				constructor(id,name,cost,type){
					super(id,name,cost);
					this.type=type;
				}
				printAllProduct()
				{
					super.printAllProduct();
					console.log("Mobile Type:"+this.type)
					
				}
			}
			var a=new Product1(1,"ABC",12000,"Basic phone")
			
class Product2 extends Product
			{
				constructor(id,name,cost,type){
					super(id,name,cost);
					this.type=type;
				}
				printAllProduct()
				{
					super.printAllProduct();
					console.log("Mobile Type:"+this.type)
					
				}
			}
			var b=new Product1(2,"ABC",15000,"Smart phone")
			
			console.log(a.printAllProduct())
			console.log(b.printAllProduct())
			
