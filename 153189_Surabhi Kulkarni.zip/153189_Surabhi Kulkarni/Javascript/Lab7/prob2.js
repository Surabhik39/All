function showCategory()
{
	var obj=window.document.frmLab.category;
	var category=new Array("Electronics","Grocery");
	for(var i=0;i<category.length;i++)
	{
		obj.options[i]=new Option(category[i],category[i]);
	}
}

function populateProduct(){
	var catObj=window.document.frmLab.category;
	var proObj=window.document.frmLab.product;
	var catSelectedIndex=catObj.selectedIndex;
	var products=new Array();
	products[0]=new Array("Television","Laptop","Phone");
	products[1]=new Array("Soap","Powder");
	for(var i=0;i<products[catSelectedIndex].length;i++)
	{
		proObj.options[i]=new Option(products[catSelectedIndex][i],products[catSelectedIndex][i]);
	}
}

function price()
{
	var catObj=window.document.frmLab.category;
	var proObj=window.document.frmLab.product;
	var catIndex=catObj.selectedIndex;
	var proIndex=proObj.selectedIndex;
	var res;
	var quantity=document.getElementById("qunId").value;
	if(catIndex==0&&proIndex==0)
	{
		res=20000*quantity;
	}
	if(catIndex==0&&proIndex==1)
	{
		res=30000*quantity;
	}
	if(catIndex==0&&proIndex==2)
	{
		res=10000*quantity;
	}
	if(catIndex==1&&proIndex==0)
	{
		res=40*quantity;
	}
	if(catIndex==1&&proIndex==1)
	{
		res=90*quantity;
	}
	document.getElementById("totalId").value=res;
}