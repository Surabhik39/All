function sayHello()
{
	document.write("Hello World");
}