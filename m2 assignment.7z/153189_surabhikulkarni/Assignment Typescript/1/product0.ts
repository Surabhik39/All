class Mobile{
				constructor(id,name,cost){
					this.id=id;
					this.name=name;
					this.cost=cost
				}
				printAllProduct()
				{
					console.log("Mobile ID:"+this.id)
					console.log("Mobile Name:"+this.name)
					console.log("Mobile cost:"+this.cost)
				}
			}