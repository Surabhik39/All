"use strict";
exports.__esModule = true;
var Mobile = /** @class */ (function () {
    function Mobile(id, name, cost) {
        this.id = id;
        this.name = name;
        this.cost = cost;
    }
    Mobile.prototype.printAllProduct = function () {
        console.log("Mobile ID:" + this.id);
        console.log("Mobile Name:" + this.name);
        console.log("Mobile cost:" + this.cost);
    };
    return Mobile;
}());
exports.Mobile = Mobile;
