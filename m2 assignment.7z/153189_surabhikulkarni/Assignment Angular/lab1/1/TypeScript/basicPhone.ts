import {Mobile} from './mobile';

export class BasicPhone extends Mobile
			{
				type;
				constructor(id,name,cost,type){
					super(id,name,cost);
					this.type=type;
				}
				printAllProduct()
				{
					super.printAllProduct();
					console.log("Mobile Type:"+this.type)
					
				}
			}
		