"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    }
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
exports.__esModule = true;
var smartPhone_1 = require("./smartPhone");
var basicPhone_1 = require("./basicPhone");
var BasicPhoneDetails = /** @class */ (function (_super) {
    __extends(BasicPhoneDetails, _super);
    function BasicPhoneDetails() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BasicPhoneDetails.prototype.printMobileDetails = function () {
        _super.prototype.printAllProduct.call(this);
    };
    return BasicPhoneDetails;
}(basicPhone_1.BasicPhone));
var SmartPhoneDetails = /** @class */ (function (_super) {
    __extends(SmartPhoneDetails, _super);
    function SmartPhoneDetails() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    SmartPhoneDetails.prototype.printMobileDetails = function () {
        _super.prototype.printAllProduct.call(this);
    };
    return SmartPhoneDetails;
}(smartPhone_1.SmartPhone));
var mobileData = [
    {
        "mobileId": 1001,
        "mobileName": "NOKIA",
        "mobileCost": 12300,
        "mobileType": "Basic Phone"
    },
    {
        "mobileId": 2001,
        "mobileName": "MOTO",
        "mobileCost": 16300,
        "mobileType": "Smart Phone"
    }
];
var BPD = new BasicPhoneDetails(mobileData[0].mobileId, mobileData[0].mobileName, mobileData[0].mobileCost, mobileData[0].mobileType);
console.log(BPD.printMobileDetails());
var SPD = new SmartPhoneDetails(mobileData[1].mobileId, mobileData[1].mobileName, mobileData[1].mobileCost, mobileData[1].mobileType);
console.log(SPD.printMobileDetails());
