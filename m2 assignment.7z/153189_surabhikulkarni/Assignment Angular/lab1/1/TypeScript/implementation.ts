import {SmartPhone} from './smartPhone';
import {BasicPhone} from './basicPhone';

class BasicPhoneDetails extends BasicPhone{
    printMobileDetails(){
        super.printAllProduct();
    }
}

class SmartPhoneDetails extends SmartPhone{
    printMobileDetails(){
        super.printAllProduct();
    }
}

let mobileData = [
    {
        "mobileId": 1001,
        "mobileName": "NOKIA",
        "mobileCost": 12300,
        "mobileType": "Basic Phone"
    },
    {
        "mobileId": 2001,
        "mobileName": "MOTO",
        "mobileCost": 16300,
        "mobileType": "Smart Phone"
    }
]


let BPD = new BasicPhoneDetails( 
    mobileData[0].mobileId, mobileData[0].mobileName, mobileData[0].mobileCost,mobileData[0].mobileType);
console.log(BPD.printMobileDetails());

let SPD = new SmartPhoneDetails( 
    mobileData[1].mobileId, mobileData[1].mobileName, mobileData[1].mobileCost,mobileData[1].mobileType);
console.log(SPD.printMobileDetails());