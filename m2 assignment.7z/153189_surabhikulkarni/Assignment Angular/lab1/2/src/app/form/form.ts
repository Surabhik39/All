export class User
{
    id:string;
    name:string;
    salary:number;
    department:string;
}