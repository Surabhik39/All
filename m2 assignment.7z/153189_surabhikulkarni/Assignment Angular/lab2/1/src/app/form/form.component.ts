import { Component, OnInit ,Input} from '@angular/core';
import {User} from './form';
  
  

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
  
users: User[]=[
{id:1001,name:"Rahul",salary:9000,department:"Java"},
{id:1002,name:"Sachin",salary:19000,department:"OraApps"},
{id:1003,name:"Vikash",salary:29000,department:"BI"},
];

 selectedId:number;
 selectedName:string;
 selectedSal:number;
 selectedDept:string;
  

  constructor() { }
 

  ngOnInit() {
   
  }
  title = 'Angular 2 operation';


  onAdd(a,b,c,d)
  {
    
    this.users.push({
      'id':a,
      'name':b,
      'salary':c,
      'department':d
    }
    )
   
    //this.getUserData();
  }
  onDelete(id:number)
  {
    for(let i=this.users.length-1;i>=0;i--)
    {
      if(this.users[i].id==id)
      {
        this.users.splice(i,1)
      }
    }
  }

  updateData(id,name,sal,dept):void{
    this.selectedId = id;
    this.selectedName=name;
    this.selectedSal=sal;
    this.selectedDept=dept;
  }
  onUpdate(a,b,c,d)
  {
    console.log(a,b,c,d)


   for(let i=this.users.length-1;i>=0;i--)
    {
      if(this.users[i].id==this.selectedId)
      {
        if(a!=null)
          {
           this.users[i].id=a;
           a='';
          } 
        else
       {
         this.users[i].id=this.selectedId;
         this.selectedId=null;
        }

        if(b!=null)
          {
           this.users[i].name=b;
           b='';
          } 
        else
       {
         this.users[i].name=this.selectedName;
         this.selectedName='';
        }

         if(c!=null)
          {
           this.users[i].salary=c;
           c='';
          } 
        else
       {
         this.users[i].salary=this.selectedSal;
         this.selectedSal=null;
        }

         if(d!=null)
          {
           this.users[i].department=d;
           d='';
          } 
        else
       {
         this.users[i].department=this.selectedDept;
         this.selectedDept='';
        }


        /*
       if(this.users[i].id!==this.selectedId){
        
         console.log(this.users[i].id)
       }*/
       
        
      
      

      //return id;
      }
    
  }

    }
   
}


