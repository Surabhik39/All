export interface Config {
    id: string;
    title: string;
   
    author: string;
     year: string
}