import { Pipe, PipeTransform } from '@angular/core';
import {Config} from './configInt'

@Pipe({
  name: 'yearFilter'
})
export class ConfigYearPipe implements PipeTransform {

  str:string;
  transform(books: Config[], args: string[]): Config[] {
    // let filter:string = args[0] ? args[0].toString().toLocaleLowerCase() : null ;
    //     return filter? value.filter((book:Book)=> book.title.toLocaleLowerCase().indexOf(filter) != -1) : value;

    if(!books) return [];
    if(!args) return books;
    this.str = args.toString().toLocaleLowerCase();
      return books.filter( book =>book.year.toString().toLocaleLowerCase().includes(this.str));
  }
}
