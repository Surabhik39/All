import { ConfigYearPipe } from './config-year.pipe';

describe('ConfigYearPipe', () => {
  it('create an instance', () => {
    const pipe = new ConfigYearPipe();
    expect(pipe).toBeTruthy();
  });
});
