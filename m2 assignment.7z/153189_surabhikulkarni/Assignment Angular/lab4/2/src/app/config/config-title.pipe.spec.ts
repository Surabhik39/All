import { ConfigTitlePipe } from './config-title.pipe';

describe('ConfigTitlePipe', () => {
  it('create an instance', () => {
    const pipe = new ConfigTitlePipe();
    expect(pipe).toBeTruthy();
  });
});
