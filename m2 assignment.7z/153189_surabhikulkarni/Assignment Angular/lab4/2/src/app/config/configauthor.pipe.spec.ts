import { ConfigauthorPipe } from './configauthor.pipe';

describe('ConfigauthorPipe', () => {
  it('create an instance', () => {
    const pipe = new ConfigauthorPipe();
    expect(pipe).toBeTruthy();
  });
});
