import { Injectable ,OnInit} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {Config} from './config/configInt';
import {Observable} from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class ConfigService implements OnInit {
  constructor(private http: HttpClient) { }
  configUrl = 'assets/booklist.json';

ngOnInit(){
  this.getConfig();
}

getConfig():Observable<Config[]> {
  // now returns an Observable of Config
  return this.http.get<Config[]>(this.configUrl);
}

}


