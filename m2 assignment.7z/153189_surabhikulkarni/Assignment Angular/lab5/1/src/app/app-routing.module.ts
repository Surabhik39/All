import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';

import { AddMoviesComponent } from './add-movies/add-movies.component';
import { SearchMoviesComponent } from './search-movies/search-movies.component';

const routes: Routes = [
  { path: '', redirectTo: '/searchmovies', pathMatch: 'full' },
  { path: 'searchmovies', component: SearchMoviesComponent},
  { path: 'addmovies', component: AddMoviesComponent }
];

@NgModule({
  imports: [
    CommonModule,
     RouterModule.forRoot(routes)
  ],
  exports: [ RouterModule ],
  declarations: []
})
export class AppRoutingModule { }
