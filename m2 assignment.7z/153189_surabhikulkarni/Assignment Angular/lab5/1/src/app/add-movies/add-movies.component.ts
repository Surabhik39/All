import { Component, OnInit } from '@angular/core';

import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-add-movies',
  templateUrl: './add-movies.component.html',
  styleUrls: ['./add-movies.component.css']
})
export class AddMoviesComponent implements OnInit {
  categories=['Drama','Fiction','Satire']

  constructor() { }

  ngOnInit() {
  }

  onSubmit(myform:NgForm)
  {

  }
}
