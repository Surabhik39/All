export class Product {
  productId: number;
  productName: string;
  imageUrl : string;
  pagedisplay:string
}



